package top.weixiansen574.bilibiliArchive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import top.weixiansen574.bilibiliArchive.bean.VideoBackupConfig;
import top.weixiansen574.bilibiliArchive.core.biliApis.BiliBiliApiException;
import top.weixiansen574.bilibiliArchive.core.http.HttpLogger;
import top.weixiansen574.bilibiliArchive.mapper.master.BackupFavMapper;
import top.weixiansen574.bilibiliArchive.mapper.master.VideoBackupConfigMapper;
import top.weixiansen574.bilibiliArchive.mapper.master.VideoInfoMapper;
import top.weixiansen574.bilibiliArchive.services.BackupService;
import top.weixiansen574.bilibiliArchive.services.CommentService;
import top.weixiansen574.bilibiliArchive.services.FileService;
import top.weixiansen574.bilibiliArchive.services.UserService;

import java.io.File;
import java.io.IOException;

@SpringBootApplication

public class BilibiliArchiveApplication {

    public static void main(String[] args) throws BiliBiliApiException, IOException {
        ConfigurableApplicationContext context = SpringApplication.run(BilibiliArchiveApplication.class, args);
        FileService fileService = context.getBean(FileService.class);

        System.out.println(fileService);

        /*VideoInfoMapper mapper = context.getBean(VideoInfoMapper.class);*/
        BackupFavMapper backupFavMapper = context.getBean(BackupFavMapper.class);

        System.out.println(backupFavMapper.selectAllEnabled());

        /*CommentService commentService = context.getBean(CommentService.class);
        System.out.println(commentService.getClass());
        System.out.println(CommentService.class);
        //System.out.println(commentService.getClass().equals(CommentService.class));
        //System.out.println(commentService);
        commentService.test();
        //for (ArchiveComment archiveComment : cursor) {*/

        //context.close();
    }

}
