package top.weixiansen574.bilibiliArchive.bean;

import top.weixiansen574.bilibiliArchive.bean.config.CommentDownloadConfig;
import top.weixiansen574.bilibiliArchive.bean.config.VideoContentUpdateConfig;
import top.weixiansen574.bilibiliArchive.bean.config.VideoDownloadConfig;

import java.util.List;

public class VideoBackupConfig {
    public Integer id;
    public String name;
    public VideoDownloadConfig video;
    public CommentDownloadConfig comment;//为null不备份评论
    public List<VideoContentUpdateConfig> update;//为null不更新

    @Override
    public String toString() {
        return "VideoBackupConfig{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", video=" + video +
                ", comment=" + comment +
                ", update=" + update +
                '}';
    }
}
