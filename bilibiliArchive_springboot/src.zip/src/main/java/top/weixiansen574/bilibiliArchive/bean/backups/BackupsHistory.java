package top.weixiansen574.bilibiliArchive.bean.backups;

import top.weixiansen574.bilibiliArchive.bean.VideoBackupConfig;

public class BackupsHistory {
    public Long uid;
    public String autoDeleteMethod;
    public Integer deleteByDays;
    public Long deleteByDiskUsage;
    public Integer deleteByItemQuantity;
    public Integer releaseTimeLimitDay;
    public String uploaderBlackList;
    public Integer videoBackupEnable;
    public Integer videoBackupConfigId;

    public VideoBackupConfig videoBackupConfig;

    public BackupsHistory() {}

    public BackupsHistory(Long uid, String autoDeleteMethod, Integer deleteByDays, Long deleteByDiskUsage,
                          Integer deleteByItemQuantity, Integer releaseTimeLimitDay, String uploaderBlackList,
                          Integer videoBackupEnable, Integer videoBackupConfigId) {
        this.uid = uid;
        this.autoDeleteMethod = autoDeleteMethod;
        this.deleteByDays = deleteByDays;
        this.deleteByDiskUsage = deleteByDiskUsage;
        this.deleteByItemQuantity = deleteByItemQuantity;
        this.releaseTimeLimitDay = releaseTimeLimitDay;
        this.uploaderBlackList = uploaderBlackList;
        this.videoBackupEnable = videoBackupEnable;
        this.videoBackupConfigId = videoBackupConfigId;
    }
}
