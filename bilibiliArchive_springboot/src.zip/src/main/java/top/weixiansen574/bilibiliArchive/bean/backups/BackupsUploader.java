package top.weixiansen574.bilibiliArchive.bean.backups;

public class BackupsUploader {
    public Long uploaderUid;
    public String uploaderName;
    public String uploaderDesc;
    public String uploaderAvatarUrl;
    public Integer startBackupTime;
    public Long backupUserId;
    public Boolean videoBackupEnable;
    public Integer videoBackupConfigId;
    public Boolean dynamicBackupEnable;
    public String dynamicBackupConfig;
    public Boolean articleBackupEnable;
    public String articleBackupConfig;
    public Boolean liveRecordingEnable;
    public String liveRecordingConfig;

    // 构造函数（可选）
    public BackupsUploader() {}

    // 如果需要，可以添加一个包含所有字段的构造函数
    public BackupsUploader(Long uploaderUid, String uploaderName, String uploaderDesc, String uploaderAvatarUrl,
                           Integer startBackupTime, Long backupUserId, Boolean videoBackupEnable, Integer videoBackupConfigId,
                           Boolean dynamicBackupEnable, String dynamicBackupConfig, Boolean articleBackupEnable, String articleBackupConfig,
                           Boolean liveRecordingEnable, String liveRecordingConfig) {
        this.uploaderUid = uploaderUid;
        this.uploaderName = uploaderName;
        this.uploaderDesc = uploaderDesc;
        this.uploaderAvatarUrl = uploaderAvatarUrl;
        this.startBackupTime = startBackupTime;
        this.backupUserId = backupUserId;
        this.videoBackupEnable = videoBackupEnable;
        this.videoBackupConfigId = videoBackupConfigId;
        this.dynamicBackupEnable = dynamicBackupEnable;
        this.dynamicBackupConfig = dynamicBackupConfig;
        this.articleBackupEnable = articleBackupEnable;
        this.articleBackupConfig = articleBackupConfig;
        this.liveRecordingEnable = liveRecordingEnable;
        this.liveRecordingConfig = liveRecordingConfig;
    }
}
