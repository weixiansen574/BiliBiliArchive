package top.weixiansen574.bilibiliArchive.bean.videoinfo;


public class FavoriteVideoInfo extends ArchiveVideoInfo {
    public long favoritesId;
    public long favTime;
}
