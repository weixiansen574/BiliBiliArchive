package top.weixiansen574.bilibiliArchive.bean.videoinfo;

public class HistoryVideoInfo extends ArchiveVideoInfo {
    public long uid;
    public long viewAt;

}
