package top.weixiansen574.bilibiliArchive.bean.videoinfo;

public class UploaderVideoInfo extends ArchiveVideoInfo {
    public long uid;
    public long created;
}
