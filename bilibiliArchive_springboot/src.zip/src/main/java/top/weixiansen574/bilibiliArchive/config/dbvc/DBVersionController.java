package top.weixiansen574.bilibiliArchive.config.dbvc;

import java.sql.Connection;
import java.sql.SQLException;

public abstract class DBVersionController {
    public final DBExe dbExe;
    public final int version;

    public DBVersionController(Connection connection, int version) {
        this.dbExe = new DBExe(connection);
        this.version = version;
    }

    public final void doInit() throws SQLException {
        int currentVersion = getVersion();
        int dbVersion = getDBVersion();
        if (currentVersion > dbVersion){
            onUpgrade(dbVersion,currentVersion);
        }
        dbExe.connection().close();
    }

    public abstract void onCreate() throws SQLException;

    public abstract void onUpgrade(int oldVersion, int newVersion) throws SQLException;

    public int getVersion(){
        return version;
    }

    public abstract int getDBVersion() throws SQLException;

    public abstract void setDBVersion(int newVersion) throws SQLException;

}
