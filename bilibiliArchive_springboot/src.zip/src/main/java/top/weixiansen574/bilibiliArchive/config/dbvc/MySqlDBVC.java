package top.weixiansen574.bilibiliArchive.config.dbvc;

import java.sql.Connection;
import java.sql.SQLException;

public abstract class MySqlDBVC extends DBVersionController{

    public MySqlDBVC(Connection connection, int version) {
        super(connection, version);
    }

    @Override
    public int getDBVersion() throws SQLException {
        return 0;
    }

    @Override
    public void setDBVersion(int newVersion) throws SQLException {

    }
}
