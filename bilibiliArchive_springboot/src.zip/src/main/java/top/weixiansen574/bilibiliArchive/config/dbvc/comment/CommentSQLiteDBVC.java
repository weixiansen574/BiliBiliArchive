package top.weixiansen574.bilibiliArchive.config.dbvc.comment;

import top.weixiansen574.bilibiliArchive.config.dbvc.SQLiteDBVC;

import java.sql.Connection;
import java.sql.SQLException;

public class CommentSQLiteDBVC extends SQLiteDBVC {
    public static final int VERSION = 1;

    public CommentSQLiteDBVC(Connection connection) {
        super(connection, VERSION);
    }

    @Override
    public void onCreate() throws SQLException {

    }

    @Override
    public void onUpgrade(int oldVersion, int newVersion) throws SQLException {

    }
}
