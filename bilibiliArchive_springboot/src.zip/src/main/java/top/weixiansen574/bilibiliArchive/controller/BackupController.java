package top.weixiansen574.bilibiliArchive.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/backup")
public class BackupController {
    //status

    //GET video-backup-config 获取所有视频备份配置，且按照优先级排序
    //POST video-backup-config 新建一个视频备份配置

    //GET PUT video-backup-config/{id} 获取或更新特定的视频备份配置

    //user-fav/{uid}
    //fav/{fid}
    //history/{uid}
    //user-uploader/{uid}
    //uploader/{upUid}

}