package top.weixiansen574.bilibiliArchive.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.weixiansen574.bilibiliArchive.bean.BiliUser;
import top.weixiansen574.bilibiliArchive.mapper.master.UserMapper;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    UserMapper userMapper;

    @Autowired
    public UserController(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @GetMapping
    public List<BiliUser> getAll(){
        return userMapper.selectAll();
    }

    @GetMapping("{uid}")
    public BiliUser getByUid(@PathVariable long uid){
        return userMapper.selectByUid(uid);
    }


}
