package top.weixiansen574.bilibiliArchive.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.weixiansen574.bilibiliArchive.bean.videoinfo.ArchiveVideoInfo;
import top.weixiansen574.bilibiliArchive.mapper.master.VideoFavoriteMapper;
import top.weixiansen574.bilibiliArchive.mapper.master.VideoHistoryMapper;
import top.weixiansen574.bilibiliArchive.mapper.master.VideoInfoMapper;
import top.weixiansen574.bilibiliArchive.mapper.master.VideoUploaderMapper;

@RestController
@RequestMapping("/video")
public class VideoController {
    //info/{bvid}
    //favorite/{favId}
    //history/{uid}
    //uploader/{upUid}
    VideoInfoMapper videoInfoMapper;
    VideoFavoriteMapper videoFavoriteMapper;
    VideoHistoryMapper videoHistoryMapper;
    VideoUploaderMapper videoUploaderMapper;

    @Autowired
    public VideoController(VideoInfoMapper videoInfoMapper, VideoFavoriteMapper videoFavoriteMapper, VideoHistoryMapper videoHistoryMapper, VideoUploaderMapper videoUploaderMapper) {
        this.videoInfoMapper = videoInfoMapper;
        this.videoFavoriteMapper = videoFavoriteMapper;
        this.videoHistoryMapper = videoHistoryMapper;
        this.videoUploaderMapper = videoUploaderMapper;
    }

    @GetMapping("info/{bvid}")
    public ArchiveVideoInfo getVideoInfo(@PathVariable String bvid){
        return videoInfoMapper.selectByBvid(bvid);
    }

}
