package top.weixiansen574.bilibiliArchive.core;

import java.util.ArrayList;
import java.util.List;

public class BackupSettings {
    public Long intervalOfLoop;
    public List<Integer> videoBackupPriorityList;

    public static BackupSettings getDefault(){
        BackupSettings settings = new BackupSettings();
        settings.intervalOfLoop = 3600000L;
        settings.videoBackupPriorityList = new ArrayList<>();
        return settings;
    }
}
