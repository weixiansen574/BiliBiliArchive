package top.weixiansen574.bilibiliArchive.core;

import top.weixiansen574.bilibiliArchive.core.backup.VideoBackup;

import java.util.List;
import java.util.concurrent.ExecutorService;

public class ContentBackupLoopThread extends Thread{
    private boolean running;
    private final long interval;
    ExecutorService taskPoll;
    List<VideoBackup> videoBackups;

    public ContentBackupLoopThread(long interval, ExecutorService taskPoll, List<VideoBackup> videoBackups) {
        this.interval = interval;
        this.taskPoll = taskPoll;
        this.videoBackups = videoBackups;
    }

    @Override
    public void run() {
        while (running) {
            //TODO 查询新视频并下载
            synchronized (this) {
                doBackup();
                try {
                    wait(interval);
                } catch (InterruptedException e) {
                    running = false;
                }
            }
        }
    }

    public void shutdown(){
        running = false;
        interrupt();
        try {
            join();
        } catch (InterruptedException ignored) {
        }
    }

    /**
     * 跳过循环线程的等待
     */
    public void jumpOverSleep() {
        synchronized (this){
            notify();
        }
    }


    private void doBackup() {

    }


}
