package top.weixiansen574.bilibiliArchive.core;

import java.util.Map;
import java.util.concurrent.ExecutorService;

public class ContentUpdateThread extends Thread {
    ExecutorService taskPoll;
    Map<Long, UserContext> userContextMap;


    @Override
    public void run() {

    }
}
