package top.weixiansen574.bilibiliArchive.core;

import okhttp3.OkHttpClient;
import top.weixiansen574.bilibiliArchive.bean.BiliUser;
import top.weixiansen574.bilibiliArchive.core.biliApis.BiliApiService;

public record UserContext(BiliUser biliUser, OkHttpClient httpClient,
                          BiliApiService biliApiService) {
}
