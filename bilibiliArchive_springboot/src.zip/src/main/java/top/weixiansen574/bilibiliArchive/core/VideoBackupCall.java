package top.weixiansen574.bilibiliArchive.core;

import top.weixiansen574.bilibiliArchive.mapper.master.VideoInfoMapper;

public abstract class VideoBackupCall {
    VideoInfoMapper mapper;
    public abstract int getVideoBackupConfigId();
}
