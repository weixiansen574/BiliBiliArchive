package top.weixiansen574.bilibiliArchive.core.backup;

import top.weixiansen574.bilibiliArchive.core.VideoBackupCall;

import java.util.List;
import java.util.Map;

public class HistoryVideoBackup extends VideoBackup{
    @Override
    public List<VideoBackupCall> getPendingBackupVideos() {
        return null;
    }

    @Override
    public void commit(Map<String, Boolean> downloadedBvidMap) {

    }

    @Override
    public String getDesc() {
        return "XX的历史记录";
    }
}
