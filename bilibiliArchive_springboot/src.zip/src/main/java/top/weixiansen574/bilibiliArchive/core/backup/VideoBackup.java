package top.weixiansen574.bilibiliArchive.core.backup;

import top.weixiansen574.bilibiliArchive.core.UserContext;
import top.weixiansen574.bilibiliArchive.core.VideoBackupCall;
import top.weixiansen574.bilibiliArchive.mapper.master.VideoInfoMapper;

import java.util.List;
import java.util.Map;

public abstract class VideoBackup {

    public int priority;

    public abstract List<VideoBackupCall> getPendingBackupVideos();
    public abstract void commit(Map<String,Boolean> downloadedBvidMap);
    public abstract String getDesc();
}
