package top.weixiansen574.bilibiliArchive.core.biliApis;


import okhttp3.HttpUrl;
import okhttp3.Request;
import okio.Timeout;
import org.jetbrains.annotations.NotNull;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import top.weixiansen574.bilibiliArchive.core.biliApis.model.GeneralResponse;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.TreeMap;

public record ApiCall<T extends GeneralResponse<R>, R>(Call<T> delegate, WbiFactory wbiFactory) implements Call<T> {

    @NotNull
    @Override
    public Response<T> execute() throws IOException {
        // 可以在这里对请求结果进行自定义处理
        // 对 response 进行自定义处理
        if (wbiFactory != null) {
            try {
                Class<?> clazz = delegate.getClass();
                Field rawCallField = clazz.getDeclaredField("rawCall");
                Field executedField = clazz.getDeclaredField("executed");
                rawCallField.setAccessible(true);
                executedField.setAccessible(true);
                okhttp3.Call.Factory callFactory = getCallFactory();
                rawCallField.set(delegate, callFactory.newCall(requestAddWbi(wbiFactory, callFactory)));
                Response<T> response = delegate.execute();
                //如果wbi失效，尝试刷新一次，再返回重试的请求结果
                //错误号:412
                //由于触发哔哩哔哩安全风控策略，该次访问请求被拒绝。
                if (response.code() == 412) {
                    wbiFactory.refresh(callFactory);
                    rawCallField.set(delegate, callFactory.newCall(requestAddWbi(wbiFactory, callFactory)));
                    executedField.set(delegate,false);
                    return delegate.execute();
                }
                if (response.body() == null) {
                    return response;
                }
                //响应体JSON：code:-352  message:风控校验失败
                T body = response.body();
                if (body.code == -352 && "风控校验失败".equals(body.message)){
                    wbiFactory.refresh(callFactory);
                    rawCallField.set(delegate, callFactory.newCall(requestAddWbi(wbiFactory, callFactory)));
                    executedField.set(delegate,false);
                    return delegate.execute();
                }
                return response;
            } catch (NoSuchFieldException | IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        } else {
            return delegate.execute();
        }
    }

    @Override
    public void enqueue(@NotNull Callback<T> callback) {
        // 可以在这里自定义异步处理逻辑
        delegate.enqueue(new Callback<>() {
            @Override
            public void onResponse(@NotNull Call<T> call, @NotNull Response<T> response) {
                // 对 response 进行自定义处理
                callback.onResponse(ApiCall.this, response);
            }

            @Override
            public void onFailure(@NotNull Call<T> call, @NotNull Throwable t) {
                // 对错误进行自定义处理
                callback.onFailure(ApiCall.this, t);
            }
        });
    }

    @Override
    public boolean isExecuted() {
        return delegate.isExecuted();
    }

    @Override
    public void cancel() {
        delegate.cancel();
    }

    @Override
    public boolean isCanceled() {
        return delegate.isCanceled();
    }

    @SuppressWarnings("all")
    @NotNull
    @Override
    public ApiCall<T, R> clone() {
        return new ApiCall<>(delegate.clone(), wbiFactory);
    }

    @NotNull
    @Override
    public Request request() {
        return delegate.request();
    }

    public Request requestAddWbi(WbiFactory wbiFactory, okhttp3.Call.Factory factory) throws IOException {
        Request request = request();
        HttpUrl url = request.url();
        TreeMap<String, Object> map = new TreeMap<>();
        for (String name : url.queryParameterNames()) {
            map.put(name, url.queryParameter(name));
        }
        long wts = System.currentTimeMillis() / 1000;
        map.put("w_ts", wts);
        Wbi wbi = wbiFactory.getWbiOrFresh(factory);
        HttpUrl newUrl = url.newBuilder()
                .addQueryParameter("w_ts", String.valueOf(wts))
                .addQueryParameter("w_rid", wbi.wbiSign(map))
                .build();
        return request.newBuilder().url(newUrl).build();
    }

    @NotNull
    @Override
    public Timeout timeout() {
        return delegate.timeout();
    }

    @NotNull
    public T exe() throws IOException {
        Response<T> response = execute();
        T body = response.body();
        if (body == null) {
            throw new ResponseNullException(response);
        } else {
            return body;
        }
    }

    public R data() throws IOException {
        return exe().data;
    }

    public R success() throws IOException, BiliBiliApiException {
        return success(null);
    }

    public R success(String errorTips) throws IOException, BiliBiliApiException {
        T body = exe();
        if (body.isSuccess()) {
            return body.data;
        } else {
            throw new BiliBiliApiException(body, errorTips);
        }
    }

    private okhttp3.Call.Factory getCallFactory() {
        try {
            Class<?> clazz = delegate.getClass();
            Field callFactoryField = clazz.getDeclaredField("callFactory");
            callFactoryField.setAccessible(true);
            return (okhttp3.Call.Factory) callFactoryField.get(delegate);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }


}

