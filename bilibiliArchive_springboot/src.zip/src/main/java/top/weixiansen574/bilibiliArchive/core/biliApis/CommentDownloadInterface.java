package top.weixiansen574.bilibiliArchive.core.biliApis;

public interface CommentDownloadInterface {
    int TYPE_VIDEO = 1;


    int SORT_BY_TIME = 0;
    int SORT_BY_LIKE = 1;
    int SORT_BY_REPLY = 2;

    int MODE_SORT_HOT0 = 0;
    int MODE_SORT_HOT = 3;
    int MODE_SORT_HOT_AND_TIME = 1;
    int MODE_SORT_TIME = 2;

}
