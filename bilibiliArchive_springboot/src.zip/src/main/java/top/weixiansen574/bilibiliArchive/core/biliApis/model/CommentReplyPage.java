package top.weixiansen574.bilibiliArchive.core.biliApis.model;

public class CommentReplyPage extends CommentPage{
    public BiliComment root;
}
