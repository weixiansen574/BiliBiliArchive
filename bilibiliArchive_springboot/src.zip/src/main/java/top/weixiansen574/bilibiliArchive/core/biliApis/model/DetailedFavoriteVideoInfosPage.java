package top.weixiansen574.bilibiliArchive.core.biliApis.model;

import java.util.List;

public class DetailedFavoriteVideoInfosPage {
    public List<DetailedFavoriteVideoInfo> medias;
}
