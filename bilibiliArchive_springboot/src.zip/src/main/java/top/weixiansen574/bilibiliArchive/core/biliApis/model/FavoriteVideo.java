package top.weixiansen574.bilibiliArchive.core.biliApis.model;

public class FavoriteVideo {
    public long id;
    public int type;
    public String bvid;
}
