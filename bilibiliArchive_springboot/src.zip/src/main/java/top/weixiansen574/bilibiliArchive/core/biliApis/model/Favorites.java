package top.weixiansen574.bilibiliArchive.core.biliApis.model;

public class Favorites {
    public long id;
    public int attr;
    public String title;
}
