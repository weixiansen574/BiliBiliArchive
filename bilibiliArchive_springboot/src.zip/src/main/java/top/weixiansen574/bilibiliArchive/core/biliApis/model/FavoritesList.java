package top.weixiansen574.bilibiliArchive.core.biliApis.model;

import java.util.List;

public class FavoritesList {
    public int count;
    public List<Favorites> list;
}
