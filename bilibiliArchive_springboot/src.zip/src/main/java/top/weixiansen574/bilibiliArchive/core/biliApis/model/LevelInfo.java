package top.weixiansen574.bilibiliArchive.core.biliApis.model;

public class LevelInfo {
    public int current_level;
    public int current_min;
    public int current_exp;
    public int next_exp;
    public long level_up;
}
