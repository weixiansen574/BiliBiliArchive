package top.weixiansen574.bilibiliArchive.core.biliApis.model;

public class Pfs {
    public CalendarEvent.Profile profile;
    public CalendarEvent.LevelInfo level_info;
    public Double coins;
    public Integer following;
    public Integer follower;
    public CalendarEvent.MaskedPrivacy masked_privacy;
    public CalendarEvent.UserHonourInfo user_honour_info;
    public CalendarEvent.School school;
}
