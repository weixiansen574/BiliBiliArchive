package top.weixiansen574.bilibiliArchive.core.biliApis.model;

public class SubtitleInfo {
    public long id;
    public String lan;
    public String lan_doc;
    public boolean is_lock;
    public String subtitle_url;
    public int type;
    public String id_str;
    public int ai_type;
    public int ai_status;
}
