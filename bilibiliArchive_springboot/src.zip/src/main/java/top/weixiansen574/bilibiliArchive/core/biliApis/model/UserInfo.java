package top.weixiansen574.bilibiliArchive.core.biliApis.model;

public class UserInfo {
    public long mid;

}
