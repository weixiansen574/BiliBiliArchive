package top.weixiansen574.bilibiliArchive.core.biliApis.model;

public class UserProfile {
    public long mid;
    public String name;
    public String face;
    public int level;
    public long jointime;
    public long birthday;
}
