package top.weixiansen574.bilibiliArchive.core.downloaders;

import okhttp3.OkHttpClient;
import top.weixiansen574.bilibiliArchive.bean.ArchiveComment;
import top.weixiansen574.bilibiliArchive.bean.config.CommentDownloadConfig;
import top.weixiansen574.bilibiliArchive.core.biliApis.BiliApiService;
import top.weixiansen574.bilibiliArchive.core.biliApis.BiliBiliApiException;
import top.weixiansen574.bilibiliArchive.core.biliApis.CommentDownloadInterface;
import top.weixiansen574.bilibiliArchive.core.biliApis.model.*;
import top.weixiansen574.bilibiliArchive.core.http.ResponseNotSuccessfulException;
import top.weixiansen574.bilibiliArchive.core.util.MiscUtils;
import top.weixiansen574.bilibiliArchive.mapper.comment.AvatarMapper;
import top.weixiansen574.bilibiliArchive.mapper.comment.CommentMapper;
import top.weixiansen574.bilibiliArchive.services.FileService;

import java.io.File;
import java.io.IOException;
import java.util.List;

//TODO 重构，删了评论回复使用预览
public class CommentDownloader extends ContentDownloader implements CommentDownloadInterface {

    protected final CommentMapper commentMapper;
    protected final AvatarMapper avatarMapper;

    public CommentDownloader(OkHttpClient httpClient, BiliApiService biliApiService, FileService fileService, CommentMapper commentMapper, AvatarMapper avatarMapper) {
        super(httpClient, biliApiService, fileService);
        this.commentMapper = commentMapper;
        this.avatarMapper = avatarMapper;
    }

    /**
     * 下载评论，根据配置文件
     *
     * @param oid    评论区oid
     * @param type   评论区type
     * @param config 评论下载配置
     * @return 评论区汇报的楼层数
     */
    public int downloadOrUpdateComment(long oid, int type, CommentDownloadConfig config) throws BiliBiliApiException, IOException {
        if (config == null) {
            return 0;
        }
        //ALL 下载所有评论 置顶：每次调用都下载及其完整回复
        //HOT 按需下载热门评论 置顶：每次调用都下载及完整其回复
        //LATEST_FIRST 增量更新 置顶：本地没有评论时下载及其完整回复，否则更新点赞及预览评论
        //FLOOR_SNIFFER 楼层嗅探 置顶：本地没有评论时下载及其完整回复，否则更新点赞及预览评论
        int sortMode = MODE_SORT_TIME;
        boolean topCommentReplyUsePreview = false;

        ArchiveComment latestFirstAnchor = null;
        ArchiveComment floorAnchor = null;
        boolean floorDownload = false;
        switch (config.mode) {
            case CommentDownloadConfig.MODE_ALL -> {//2
            }
            case CommentDownloadConfig.MODE_HOT -> {//3
                sortMode = MODE_SORT_HOT;
            }
            case CommentDownloadConfig.MODE_LATEST_FIRST -> {//2
                latestFirstAnchor = commentMapper.getLatestPostedRootComment(oid, type);
            }
            case CommentDownloadConfig.MODE_FLOOR_SNIFFER -> {//_2_
                floorDownload = true;
                floorAnchor = commentMapper.getTopFloorRootComment(oid, type);
            }
            default -> throw new IllegalArgumentException("非法评论下载mode:" + config.mode);
        }
        //先按时间排序，获取第一页，获取楼层总数以及下载置顶评论（若本来就是时间排序，则下次省略）
        GeneralResponse<MainApiCommentPage> response = biliApiService
                .getCommentPageForMainApi(MODE_SORT_TIME, PaginationStr.INITIAL, oid, type).exe();
        if (response.code == 12061 || response.code == 12002) {
            //评论区已关闭
            System.out.println("因为：" + response.message + "，跳过评论下载");
            return 0;
        } else if (!response.isSuccess()) {
            throw new BiliBiliApiException(response, "获取评论页失败");
        }
        int savedRootCount = 0;
        int savedReplyCount = 0;
        MainApiCommentPage page = response.data;
        int totalCount = page.cursor.all_count;
        int totalFloor = page.cursor.prev - 1;
        System.out.println("当前评论区楼数：" + totalFloor);
        savedRootCount += saveTopComments(page);
        savedReplyCount += saveTopCommentReplies(page, -1);
        //不是按时间时，重新按参数获取一遍，使其正常前进
        if (sortMode != MODE_SORT_TIME) {
            page = biliApiService.getCommentPageForMainApi(sortMode, PaginationStr.INITIAL, oid, type).success();
        }
        //=========================
        if (floorDownload) {
            //TODO 楼层下载
            int floorLimit = 0;
            if (floorAnchor != null && floorAnchor.floor != null) {
                floorLimit = floorAnchor.floor;
            }
            BiliComment comment;
            int cFloor;
            if (page.replies != null) {
                comment = page.replies.get(0);
                cFloor = totalFloor;
                System.out.println(comment);
            } else {
                return totalFloor;
            }
            String pStr;
            for (int i = totalFloor - 1; i > 0; i--) {
                pStr = "{\"offset\":\"{\\\"type\\\":3,\\\"direction\\\":1,\\\"Data\\\":{\\\"cursor\\\":" + i + "}}\"}";
                page = biliApiService.getCommentPageForMainApi(MODE_SORT_TIME, pStr, oid, type).success();
                List<BiliComment> replies = page.replies;
                if (replies != null) {
                    if (replies.isEmpty()) {
                        break;
                    }
                    BiliComment currentComment = replies.get(0);
                    if (currentComment.rpid != comment.rpid) {
                        System.out.println("#" + cFloor + " " + comment);
                        saveCommentAndAvatarAndPictures(comment, cFloor);
                        downloadReplies(comment, -1);
                        comment = currentComment;
                    }
                    cFloor = i;
                    try {
                        //降低api调用速率
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else {
                    break;
                }
                if (i <= floorLimit){
                    return totalFloor;
                }
            }
            System.out.println("#" + cFloor + " " + comment);
            saveCommentAndAvatarAndPictures(comment, cFloor);
            downloadReplies(comment, -1);
            return totalFloor;
        }
        int rootLimit = -1;
        if (config.rootLimit != null) {
            rootLimit = config.rootLimit;
        }
        long timeAnchor = 0;
        if (latestFirstAnchor != null) {
            timeAnchor = latestFirstAnchor.ctime;
        }
        flipPage:
        while (true) {
            List<BiliComment> comments = page.replies;
            //翻页到没有评论的时候停止翻页
            if (comments == null || comments.size() == 0) {
                break;
            }
            for (BiliComment comment : comments) {
                saveCommentAndAvatarAndPictures(comment);
                savedReplyCount += downloadReplies(comment, -1);
                savedRootCount++;
                System.out.printf("\r已下载评论[%d:%d/%d][%d][%s]", savedRootCount,
                        savedRootCount + savedReplyCount, totalCount, comment.rpid,
                        MiscUtils.omit(comment.getMessage(), 30).replace("\n", " "));
                //下载的根评论数量满足要求后退出翻页
                if (rootLimit != -1 && savedRootCount >= rootLimit) {
                    System.out.printf("\n下载的根评论数量已达到[%d/%d]，完成下载！%n", savedRootCount, rootLimit);
                    break flipPage;
                }
                if (comment.ctime <= timeAnchor) {
                    System.out.printf("\n下载的评论已到时间锚点位置[时间锚点：%d <= 当前评论：%d]，完成下载！%n",
                            timeAnchor, comment.ctime);
                    break flipPage;
                }
            }
            if (page.cursor.pagination_reply == null || page.cursor.pagination_reply.next_offset == null) {
                break;
            }
            page = biliApiService.getCommentPageForMainApi(sortMode,
                    new PaginationStr(page.cursor.pagination_reply.next_offset).toJson(), oid, type).success();
        }
        System.out.println("\n评论下载完毕");
        return totalFloor;
    }


    /**
     * 下载评论回复
     *
     * @param rootComment 根评论
     *
     * At param usePreview  true:从根评论的预览列表获取评论 false:api请求获取所有评论（已移除）
     * @return 下载的评论数量
     */
    public int downloadReplies(BiliComment rootComment, int limit) throws IOException, BiliBiliApiException {
        int count = 0;
        //如果评论回复预览评论的数量与评论声明的回复数量一致，则直接在预览列表中取，节约时间
        if (rootComment.replies != null && rootComment.replies.size() == rootComment.rcount) {
            for (BiliComment reply : rootComment.replies) {
                saveCommentAndAvatarAndPictures(reply);
                count++;
            }
            return count;
        }

        for (int pn = 1; true; pn++) {
            //TODO holy shit!回复下载时，根评论die了！解决一下吧
            CommentReplyPage replyPage = biliApiService.getCommentReplyPage(rootComment.rpid,
                    rootComment.oid, pn, rootComment.type).success();
            List<BiliComment> replies = replyPage.replies;
            if (replies == null || replies.size() == 0) {
                break;
            }
            for (BiliComment reply : replies) {
                System.out.printf("\r正在下载评论回复[%d/%d][%d][%s]", count, rootComment.rcount, reply.rpid,
                        MiscUtils.omit(reply.getMessage(), 30).replace("\n", " "));
                saveCommentAndAvatarAndPictures(reply);
                count++;
            }
        }
        return count;
    }

    private int saveTopComments(CommentPage cPage) throws IOException {
        List<BiliComment> topReplies = cPage.top_replies;
        int count = 0;
        if (topReplies != null && !topReplies.isEmpty()) {
            for (BiliComment topReply : topReplies) {
                System.out.printf("置顶评论[%d][%s]\n", topReply.rpid,
                        MiscUtils.omit(topReply.getMessage(), 30).replace("\n", " "));
                saveCommentAndAvatarAndPictures(topReply);
                count++;
            }
        } else {
            System.out.println("无置顶评论");
        }
        return count;
    }

    private int saveTopCommentReplies(CommentPage cPage, int limit) throws IOException, BiliBiliApiException {
        List<BiliComment> topReplies = cPage.top_replies;
        int count = 0;
        if (topReplies != null) {
            for (BiliComment topReply : topReplies) {
                count += downloadReplies(topReply, limit);
            }
        }
        return count;
    }

    private void saveCommentAndAvatarAndPictures(BiliComment comment, Integer floor) throws IOException {
        synchronized (ContentDownloader.class) {
            //下载头像
            String avatarUrl = comment.member.avatar;
            //头像文件名，也就是URL路径后面的那串文件名
            String avatarName = MiscUtils.getEndPathForHttpUrl(avatarUrl);
            //检查是否已下载过头像，若没有，则下载
            if (!avatarMapper.checkExists(avatarName)) {
                try {

                    avatarMapper.insert(MiscUtils.getEndPathForHttpUrl(avatarUrl), downloadContentAndRetry(
                            createDownloadRequest(avatarUrl + "@160w_160h_1c_1s_!web-avatar-comment.avif"), 15));
                } catch (ResponseNotSuccessfulException e) {
                    if (e.response.code() == 404) {
                        System.out.println("\n用户头像[" + avatarUrl + "]404了，跳过下载");
                    } else {
                        throw e;
                    }
                }
            }
            //下载评论图片
            downloadCommentPicturesIfNotExists(comment);
            //保存评论到数据库
            insertCommentOrUpdateLike(comment, floor);
        }
    }


    private void saveCommentAndAvatarAndPictures(BiliComment comment) throws IOException {
        saveCommentAndAvatarAndPictures(comment, null);
    }

    /**
     * 下载评论图片,跳过已下载的
     *
     * @throws IOException 重试多遍还未下载成功
     */
    private void downloadCommentPicturesIfNotExists(BiliComment comment) throws IOException {
        String[] pictures = comment.getPictureUrls();
        if (pictures != null) {
            for (String pUrl : pictures) {
                File file = fileService.newCommentPictureFile(MiscUtils.getEndPathForHttpUrl(pUrl));
                if (!file.exists()) {
                    System.out.print("\r下载图片：" + pUrl);
                    try {
                        downloadContentAndRetry(createDownloadRequest(pUrl), file, 10);
                    } catch (IOException e) {
                        if (e instanceof ResponseNotSuccessfulException exception) {
                            System.out.println("\n下载图片：" + pUrl + " 收到错误码：" + exception.response.code()
                                    + " 可能图片在图床上已失效，跳过下载");
                            exception.response.close();
                        }
                    }

                } else {
                    System.out.print("\r图片：" + pUrl + "下载过，已跳过！");
                }
            }
        }
    }


    private void insertCommentOrUpdateLike(BiliComment comment,Integer floor){
        if (commentMapper.checkExists(comment.rpid)) {
            if (floor == null){
                commentMapper.updateLike(comment.like,comment.rpid);
            } else {
                commentMapper.updateLikeAndFloor(comment.like, floor, comment.rpid);
            }
        } else {
            commentMapper.insert(new ArchiveComment(comment,floor));
        }
    }


}
