package top.weixiansen574.bilibiliArchive.core.http;

import java.util.Date;

public record HttpLog(long index,Date date,String message) {

}
