package top.weixiansen574.bilibiliArchive.core.util;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class MiscUtils {
    public static final SimpleDateFormat cnSdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.CHINA);
    public static String getEndPathForHttpUrl(String url){
        String[] split = url.split("/");
        return split[split.length - 1];
    }


    public static String omit(String text,int length){
        if (text.length() > length){
            return text.substring(0,length) + "……";
        } else {
            return text;
        }
    }

    public static boolean matchOne(String src, String... dst) {
        for (String s : dst) {
            if (src.equals(s)) {
                return true;
            }
        }
        return false;
    }
}
