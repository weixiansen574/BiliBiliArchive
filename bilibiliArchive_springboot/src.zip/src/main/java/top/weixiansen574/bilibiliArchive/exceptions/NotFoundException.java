package top.weixiansen574.bilibiliArchive.exceptions;

public class NotFoundException extends Exception{
}
