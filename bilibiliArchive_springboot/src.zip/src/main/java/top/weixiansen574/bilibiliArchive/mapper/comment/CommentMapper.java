package top.weixiansen574.bilibiliArchive.mapper.comment;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.cursor.Cursor;
import org.springframework.stereotype.Repository;
import top.weixiansen574.bilibiliArchive.bean.ArchiveComment;

import java.util.stream.Stream;

@Repository
public interface CommentMapper {
    @Insert("""
            INSERT INTO comments (
                rpid, oid, type, mid, root, parent, uname,
                current_level, location, message, like, ctime,
                pictures, avatar_url,vip_type,floor
            ) VALUES (
                #{rpid}, #{oid}, #{type}, #{mid}, #{root}, #{parent}, #{uname},
                #{currentLevel}, #{location}, #{message}, #{like}, #{ctime},
                #{pictures}, #{avatarUrl}, #{vipType}, #{floor}
            )
            """)
    void insert(ArchiveComment comment);

    @Update("UPDATE comments SET like = #{like} WHERE rpid = #{rpid}")
    void updateLike(@Param("like") int like, @Param("rpid") long rpid);

    @Update("UPDATE comments SET like = #{like},floor = #{floor} WHERE rpid = #{rpid}")
    void updateLikeAndFloor(@Param("like") int like,@Param("floor") int floor, @Param("rpid") long rpid);

    @Select("SELECT COUNT(1) FROM comments WHERE rpid = #{rpid}")
    boolean checkExists(long rpid);

    @Select("SELECT * FROM comments WHERE oid = #{oid} AND type = #{type} AND root = 0 ORDER BY ctime DESC LIMIT 1")
    ArchiveComment getLatestPostedRootComment(@Param("oid") long oid, @Param("type") int type);

    @Select("select * from comments where oid = #{oid} AND type = #{type} ORDER BY floor DESC LIMIT 1;")
    ArchiveComment getTopFloorRootComment(@Param("oid") long oid, @Param("type") int type);
}
