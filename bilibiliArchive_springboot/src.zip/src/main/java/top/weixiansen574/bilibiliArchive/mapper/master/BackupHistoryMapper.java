package top.weixiansen574.bilibiliArchive.mapper.master;

import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import top.weixiansen574.bilibiliArchive.bean.backups.BackupsFav;
import top.weixiansen574.bilibiliArchive.bean.backups.BackupsHistory;

import java.util.List;

@Repository
public interface BackupHistoryMapper {
    @Insert("""
            insert into backups_history (uid,auto_delete_method,delete_by_days,delete_by_disk_usage,delete_by_item_quantity,
            release_time_limit_day,uploader_black_list,video_backup_enable,video_backup_config_id)
            values(#{uid},#{autoDeleteMethod},#{deleteByDays},#{deleteByDiskUsage},#{deleteByItemQuantity},#{releaseTimeLimitDay},
            #{uploaderBlackList},#{videoBackupEnable},#{videoBackupConfigId})
            """)
    void insert(BackupsHistory backupsHistory);

    @Delete("DELETE FROM backups_history WHERE uid = #{uid}")
    void deleteByUid(long uid);

    @Update("""
        UPDATE backups_history SET auto_delete_method = #{autoDeleteMethod},delete_by_days = #{deleteByDays},
        delete_by_disk_usage = #{deleteByDiskUsage},delete_by_item_quantity = #{deleteByItemQuantity},
        release_time_limit_day = #{releaseTimeLimitDay},uploader_black_list = #{uploaderBlackList},
        video_backup_enable = #{videoBackupEnable},video_backup_config_id = #{videoBackupConfigId} where uid = #{uid}
        """)
    void update(BackupsHistory backupsHistory);

    @Select("SELECT * FROM backups_history WHERE uid = #{uid}")
    BackupsHistory selectByUid(long uid);

    @Select("select * from backups_history where video_backup_enable = 1")
    @Results({
            @Result(column = "video_backup_config_id", property = "videoBackupConfigId"),
            @Result(column = "video_backup_config_id", property = "videoBackupConfig",
                    one = @One(select = "top.weixiansen574.bilibiliArchive.mapper.master.VideoBackupConfigMapper.selectById"))
    })
    List<BackupsHistory> selectAllEnabled();
}
