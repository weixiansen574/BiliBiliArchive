package top.weixiansen574.bilibiliArchive.mapper.master;

import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import top.weixiansen574.bilibiliArchive.bean.backups.BackupsHistory;
import top.weixiansen574.bilibiliArchive.bean.backups.BackupsUploader;

import java.util.List;

@Repository
public interface BackupUploaderMapper {
    @Insert("""
            INSERT INTO backups_uploader (uploader_uid, uploader_name, uploader_desc, uploader_avatar_url,
            start_backup_time, backup_user_id, video_backup_enable, video_backup_config_id,
            dynamic_backup_enable, dynamic_backup_config, article_backup_enable, article_backup_config,
            live_recording_enable, live_recording_config)
            VALUES (#{uploaderUid}, #{uploaderName}, #{uploaderDesc}, #{uploaderAvatarUrl},
            #{startBackupTime}, #{backupUserId}, #{videoBackupEnable}, #{videoBackupConfigId},
            #{dynamicBackupEnable}, #{dynamicBackupConfig}, #{articleBackupEnable}, #{articleBackupConfig},
            #{liveRecordingEnable}, #{liveRecordingConfig})
            """)
    void insert(BackupsUploader backupsUploader);

    @Delete("DELETE FROM backups_uploader WHERE uploader_uid = #{uploaderUid}")
    void deleteByUpUid(long uploaderUid);

    @Update("""
        UPDATE backups_uploader
        SET uploader_name = #{uploaderName},
            uploader_desc = #{uploaderDesc},
            uploader_avatar_url = #{uploaderAvatarUrl},
            start_backup_time = #{startBackupTime},
            backup_user_id = #{backupUserId},
            video_backup_enable = #{videoBackupEnable},
            video_backup_config_id = #{videoBackupConfigId},
            dynamic_backup_enable = #{dynamicBackupEnable},
            dynamic_backup_config = #{dynamicBackupConfig},
            article_backup_enable = #{articleBackupEnable},
            article_backup_config = #{articleBackupConfig},
            live_recording_enable = #{liveRecordingEnable},
            live_recording_config = #{liveRecordingConfig}
        WHERE uploader_uid = #{uploaderUid}
        """)
    void update(BackupsUploader uploaderBackupInfo);

    @Select("SELECT * FROM backups_uploader WHERE backup_user_id = #{backupUserId}")
    List<BackupsUploader> selectByBackupUserId(long backupUserId);

    @Select("SELECT * FROM backups_uploader WHERE uploader_uid = #{uploaderUid}")
    BackupsUploader selectByUpUid(long uploaderUid);

    @Select("select * from backups_uploader where video_backup_enable = 1")
    @Results({
            @Result(column = "video_backup_config_id", property = "videoBackupConfigId"),
            @Result(column = "video_backup_config_id", property = "videoBackupConfig",
                    one = @One(select = "top.weixiansen574.bilibiliArchive.mapper.master.VideoBackupConfigMapper.selectById"))
    })
    List<BackupsUploader> selectAllVideoEnabled();
}
