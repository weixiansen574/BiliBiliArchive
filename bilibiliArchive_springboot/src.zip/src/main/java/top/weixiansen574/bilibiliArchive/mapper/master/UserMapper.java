package top.weixiansen574.bilibiliArchive.mapper.master;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;
import top.weixiansen574.bilibiliArchive.bean.BiliUser;

import java.util.List;

@Repository
public interface UserMapper {

    @Select("select * from users")
    List<BiliUser> selectAll();

    @Select("select * from users where uid = #{uid}")
    BiliUser selectByUid(long uid);

    @Insert("INSERT INTO users (uid,name,avatar_url,cookie,pfs) VALUES(#{uid},#{name},#{avatarUrl},#{cookie},#{pfs})")
    void insert(BiliUser user);

    @Delete("DELETE FROM users WHERE uid = #{uid}")
    void deleteByUid(long uid);

    @Update("UPDATE users SET name = #{name},avatar_url = #{avatarUrl},cookie = #{cookie},pfs = #{pfs}")
    void update(BiliUser user);



}
