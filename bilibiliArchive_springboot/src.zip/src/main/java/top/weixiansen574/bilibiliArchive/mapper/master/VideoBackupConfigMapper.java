package top.weixiansen574.bilibiliArchive.mapper.master;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import top.weixiansen574.bilibiliArchive.bean.VideoBackupConfig;

import java.util.List;

@Repository
public interface VideoBackupConfigMapper {

    @Select("select * from video_backup_configs where id = #{id}")
    VideoBackupConfig selectById(int id);

    @Select("select * from video_backup_configs")
    List<VideoBackupConfig> selectAll();

    @Insert("insert into video_backup_configs (id,name,video,comment,[update]) values(null,#{name},#{video},#{comment},#{update})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(VideoBackupConfig videoBackupConfig);
}
