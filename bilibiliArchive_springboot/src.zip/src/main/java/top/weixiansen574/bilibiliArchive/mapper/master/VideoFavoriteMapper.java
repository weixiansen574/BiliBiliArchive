package top.weixiansen574.bilibiliArchive.mapper.master;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import top.weixiansen574.bilibiliArchive.bean.videoinfo.FavoriteVideoInfo;

import java.util.List;

@Repository
public interface VideoFavoriteMapper {

    @Select("""
            SELECT uvf.favorites_id, uvf.fav_time, vi.*
            FROM (SELECT * FROM videos_favorite WHERE favorites_id = #{favId}) AS uvf
            LEFT JOIN video_infos AS vi ON uvf.bvid = vi.bvid ORDER BY fav_time DESC
            """)
    List<FavoriteVideoInfo> selectByFavId(@Param("favId") long favId);

    @Insert("INSERT INTO videos_favorite (favorites_id, bvid, avid, fav_time) VALUES " +
            "(#{favoritesId}, #{bvid}, #{avid}, #{favTime})")
    void insertUserFavoriteVideo(@Param("favoritesId") long favoritesId, @Param("bvid") String bvid,
                                 @Param("avid") long avid, @Param("favTime") long favTime);
}
