package top.weixiansen574.bilibiliArchive.mapper.master;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;
import top.weixiansen574.bilibiliArchive.bean.videoinfo.ArchiveVideoInfo;

@Repository
public interface VideoInfoMapper {
    @Insert("""
            INSERT INTO video_infos (
                bvid, avid, title, desc,duration,owner_mid, owner_name, owner_avatar_url,
                view, danmaku, favorite, coin, like, share, reply, tname, ctime,
                cover_url, pages_version_list, state, downloading, save_time, community_update_time,
                config_id,total_comment_floor
            ) VALUES (
                #{bvid}, #{avid}, #{title},#{desc},#{duration},#{ownerMid}, #{ownerName},
                #{ownerAvatarUrl}, #{view}, #{danmaku}, #{favorite}, #{coin},
                #{like}, #{share}, #{reply}, #{tname}, #{ctime}, #{coverUrl}, #{pagesVersionList},
                #{state}, #{downloading}, #{saveTime}, #{communityUpdateTime},
                #{configId},#{totalCommentFloor}
            )
            """)
    void insert(ArchiveVideoInfo videoInfo);

    @Select("""
            SELECT
                CASE
                    WHEN EXISTS (SELECT 1 FROM videos_favorite WHERE bvid = #{bvid}) OR
                         EXISTS (SELECT 1 FROM videos_history WHERE bvid = #{bvid}) OR
                         EXISTS (SELECT 1 FROM videos_uploader WHERE bvid = #{bvid})
                    THEN 1
                    ELSE 0
                END AS is_referenced;
            """)
    boolean checkVideoIsReferenced(String bvid);

    @Select("SELECT * FROM video_infos WHERE bvid = #{bvid}")
    ArchiveVideoInfo selectByBvid(String bvid);

    @Update("UPDATE video_infos SET state = #{state} WHERE bvid = #{bvid}")
    void updateStatus(@Param("state") String status, @Param("bvid") String bvid);

    @Update("""
            UPDATE video_infos SET
            view = #{view},danmaku = #{danmaku},favorite = #{favorite},coin = #{coin},
            like = #{like},share = #{share},reply = #{reply},pages_version_list = #{pagesVersionList},
            downloading = #{downloading},community_update_time = #{communityUpdateTime},
            config_id = #{configId},duration = #{duration},
            state = #{state},total_comment_floor = #{totalCommentFloor}
            WHERE bvid = #{bvid}
            """)
    void update(ArchiveVideoInfo videoInfo);
}
