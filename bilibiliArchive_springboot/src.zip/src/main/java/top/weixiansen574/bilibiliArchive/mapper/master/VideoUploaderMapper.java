package top.weixiansen574.bilibiliArchive.mapper.master;

import org.springframework.stereotype.Repository;

@Repository
public interface VideoUploaderMapper {

}
