package top.weixiansen574.bilibiliArchive.services;

import org.springframework.stereotype.Service;
import top.weixiansen574.bilibiliArchive.bean.VideoBackupConfig;
import top.weixiansen574.bilibiliArchive.bean.backups.BackupsFav;
import top.weixiansen574.bilibiliArchive.bean.backups.BackupsHistory;
import top.weixiansen574.bilibiliArchive.bean.backups.BackupsUploader;
import top.weixiansen574.bilibiliArchive.core.BackupSettings;
import top.weixiansen574.bilibiliArchive.core.ContentBackupLoopThread;
import top.weixiansen574.bilibiliArchive.core.ContentUpdateThread;
import top.weixiansen574.bilibiliArchive.core.UserContext;
import top.weixiansen574.bilibiliArchive.core.backup.FavVideoBackup;
import top.weixiansen574.bilibiliArchive.core.backup.VideoBackup;
import top.weixiansen574.bilibiliArchive.core.util.JSONConfig;
import top.weixiansen574.bilibiliArchive.mapper.master.*;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutorService;

@Service
public class BackupService {
    public static final int CONFIG_ID_FINAL = 0;
    private BackupSettings settings;
    private File backupSettingsFile;

    /*
    欠实现

    多账号环境下，若小号没有大会员，使用会员账号进行视频解析
    
     */


    UserService userService;

    VideoBackupConfigMapper videoBackupConfigMapper;
    BackupFavMapper backupFavMapper;
    BackupHistoryMapper backupHistoryMapper;
    BackupUploaderMapper backupUploaderMapper;

    ContentUpdateThread updateThread;
    ContentBackupLoopThread backupLoopThread;

    ExecutorService taskPoll;


    public void start(){
        Map<Long, UserContext> userContextMap = userService.createUserContextMap();

        List<BackupsFav> backupsFavList = backupFavMapper.selectAllEnabled();
        List<BackupsHistory> backupsHistoriesList = backupHistoryMapper.selectAllEnabled();
        List<BackupsUploader> backupsUploaderList = backupUploaderMapper.selectAllVideoEnabled();

        List<VideoBackup> videoBackups = new LinkedList<>();

        for (BackupsFav backupsFav : backupsFavList) {
            videoBackups.add(new FavVideoBackup());
        }

        backupLoopThread = new ContentBackupLoopThread(settings.intervalOfLoop,taskPoll,videoBackups);
        backupLoopThread.start();
    }

    public void stop(){

    }

    /**
     * 检查视频备份优先级ID列表是否在数据库中都存在
     */
    private void checkVideoBackupPriorityList(List<Integer> videoBackupPriorityList) throws PriorityListMismatchException {
        List<VideoBackupConfig> allVideoBackupConfig = videoBackupConfigMapper.selectAll();
        if (allVideoBackupConfig.size() != videoBackupPriorityList.size()) {
            throw new PriorityListMismatchException("视频配置id优先级列表与数据库中的不匹配！");
        }
        HashSet<Integer> vidSet = new HashSet<>(videoBackupPriorityList);
        for (VideoBackupConfig videoBackupConfig : allVideoBackupConfig) {
            if (!vidSet.contains(videoBackupConfig.id)) {
                throw new PriorityListMismatchException("视频配置id优先级列表与数据库中的不匹配！");
            }
        }
    }
    /**
     * 获取所有视频配置文件，并按照优先级排序
     */
    public List<VideoBackupConfig> selectAllVideoBackupConfigAndPrioritySort(){
        List<VideoBackupConfig> videoBackupConfigInfos = new LinkedList<>();
        //查询所有配置并按顺序
        for (Integer videoConfigId : settings.videoBackupPriorityList) {
            videoBackupConfigInfos.add(videoBackupConfigMapper.selectById(videoConfigId));
        }
        return videoBackupConfigInfos;
    }
    /**
     * 保存视频配置ID优先级顺序列表
     * @param ids 频配置ID优先级顺序
     * @throws IOException 保存到配置文件时出现异常
     */
    protected void changeVideoBackupPriorityList(List<Integer> ids) throws PriorityListMismatchException, IOException {
        checkVideoBackupPriorityList(ids);
        settings.videoBackupPriorityList.clear();
        settings.videoBackupPriorityList.addAll(ids);
        saveBackupSettings();
    }
    /**
     * 获取某视频备份配置的优先级
     * @param configId 视频备份配置的ID
     * @return 优先级，越低越高
     */
    public int getVideoCfgPriority(int configId) {
        if (configId == CONFIG_ID_FINAL){
            return 0;//FINAL优先级最大
        }
        for (int i = 0; i < settings.videoBackupPriorityList.size(); i++) {
            if (configId == settings.videoBackupPriorityList.get(i)) {
                return i + 1;//因为FINAL配置要占一位，所以index+1
            }
        }
        throw new RuntimeException("configId:" + configId + " 没有对应的");
    }

    private BackupSettings readBackupSettings() throws IOException {
        if (!backupSettingsFile.exists()){
            BackupSettings backupSettings = BackupSettings.getDefault();
            saveBackupSettings(backupSettings);
            return backupSettings;
        }
        return JSONConfig.readFromFile(backupSettingsFile,BackupSettings.class);
    }

    private void saveBackupSettings() throws IOException {
        saveBackupSettings(settings);
    }

    private void saveBackupSettings(BackupSettings settings) throws IOException {
        JSONConfig.writeToFile(backupSettingsFile,settings);
    }

    public static class PriorityListMismatchException extends Exception {
        public PriorityListMismatchException(String message) {
            super(message);
        }
    }


}
