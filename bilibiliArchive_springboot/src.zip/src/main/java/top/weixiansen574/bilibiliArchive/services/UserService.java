package top.weixiansen574.bilibiliArchive.services;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.ResponseBody;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import retrofit2.Retrofit;
import retrofit2.converter.fastjson.FastJsonConverterFactory;
import top.weixiansen574.bilibiliArchive.bean.BiliUser;
import top.weixiansen574.bilibiliArchive.core.UserContext;
import top.weixiansen574.bilibiliArchive.core.biliApis.ApiCallAdapterFactory;
import top.weixiansen574.bilibiliArchive.core.biliApis.BiliApiService;
import top.weixiansen574.bilibiliArchive.core.biliApis.BiliBiliApiException;
import top.weixiansen574.bilibiliArchive.core.biliApis.model.CalendarEvent;
import top.weixiansen574.bilibiliArchive.core.biliApis.model.Pfs;
import top.weixiansen574.bilibiliArchive.core.http.CookieInterceptor;
import top.weixiansen574.bilibiliArchive.core.http.HttpLogger;
import top.weixiansen574.bilibiliArchive.core.http.LoggingAndRetryInterceptor;
import top.weixiansen574.bilibiliArchive.core.util.MiscUtils;
import top.weixiansen574.bilibiliArchive.core.util.OkHttpUtil;
import top.weixiansen574.bilibiliArchive.exceptions.NotFoundException;
import top.weixiansen574.bilibiliArchive.mapper.master.UserMapper;
import top.weixiansen574.bilibiliArchive.util.FileUtil;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserService {

    private final UserMapper mapper;
    private final LoggingAndRetryInterceptor interceptor;
    private final FileService fileService;

    @Autowired
    public UserService(UserMapper mapper, LoggingAndRetryInterceptor interceptor,FileService fileService) {
        this.mapper = mapper;
        this.interceptor = interceptor;
        this.fileService = fileService;
    }

    public BiliUser addUserFromCookie(String cookie) throws BiliBiliApiException, IOException {
        OkHttpClient okHttpClient = createClient(cookie);
        Retrofit retrofit = createRetrofit(okHttpClient);
        BiliApiService biliApiService = retrofit.create(BiliApiService.class);
        CalendarEvent calendarEvent = biliApiService.getCalendarEvents().success("获取用户信息失败");
        Pfs pfs = calendarEvent.pfs;
        if (pfs == null){
            //输入的cookie未解析到用户
            return null;
        }
        BiliUser biliUser = new BiliUser(cookie,pfs);
        String avatarUrl = biliUser.avatarUrl;
        //保存用户的头像到文件
        File avatarFile = fileService.newBCUserAvatarFile(MiscUtils.getEndPathForHttpUrl(avatarUrl));
        Request request = new Request.Builder()
                .url(avatarUrl)
                .build();
        ResponseBody responseBody = OkHttpUtil.getResponseBodyNotNull(okHttpClient.newCall(request).execute());
        FileUtil.outputToFile(responseBody.bytes(),avatarFile);
        mapper.insert(biliUser);
        return biliUser;
    }

    public BiliUser updateUser(long targetUid,String cookie) throws BiliBiliApiException, IOException, UIDInconsistencyException, NotFoundException {
        BiliUser oldUser = mapper.selectByUid(targetUid);
        if (oldUser == null){
            throw new NotFoundException();
        }
        OkHttpClient okHttpClient = createClient(cookie);
        Retrofit retrofit = createRetrofit(okHttpClient);
        BiliApiService biliApiService = retrofit.create(BiliApiService.class);
        CalendarEvent calendarEvent = biliApiService.getCalendarEvents().success("获取用户信息失败");
        Pfs pfs = calendarEvent.pfs;
        if (pfs == null){
            //输入的cookie未解析到用户
            return null;
        }
        BiliUser biliUser = new BiliUser(cookie,pfs);
        if (biliUser.uid != targetUid){
            throw new UIDInconsistencyException();
        }
        //保存用户的头像到文件（如果文件发生变化）
        String avatarUrl = biliUser.avatarUrl;
        File avatarFile = fileService.newBCUserAvatarFile(MiscUtils.getEndPathForHttpUrl(avatarUrl));
        File oldAvatarFile = fileService.newBCUserAvatarFile(MiscUtils.getEndPathForHttpUrl(oldUser.avatarUrl));
        if (!oldAvatarFile.equals(avatarFile)){
            //删除旧头像文件
            FileUtil.deleteOneFile(oldAvatarFile);
            Request request = new Request.Builder()
                    .url(avatarUrl)
                    .build();
            ResponseBody responseBody = OkHttpUtil.getResponseBodyNotNull(okHttpClient.newCall(request).execute());
            FileUtil.outputToFile(responseBody.bytes(),avatarFile);
        }
        mapper.update(biliUser);
        return biliUser;
    }

    public Map<Long,UserContext> createUserContextMap(){
        List<BiliUser> biliUsers = mapper.selectAll();
        Map<Long,UserContext> userContextMap = new HashMap<>();
        for (BiliUser biliUser : biliUsers) {
            OkHttpClient client = createClient(biliUser.cookie);
            Retrofit retrofit = createRetrofit(client);
            BiliApiService biliApiService = retrofit.create(BiliApiService.class);
            userContextMap.put(biliUser.uid,new UserContext(biliUser,client,biliApiService));
        }
        return userContextMap;
    }

    private OkHttpClient createClient(String cookie){
        return new OkHttpClient().newBuilder()
                .addInterceptor(new CookieInterceptor(cookie))
                .addInterceptor(interceptor)
                .build();
    }

    private Retrofit createRetrofit(OkHttpClient okHttpClient){
        return new Retrofit.Builder()
                .baseUrl("https://api.bilibili.com")
                .addCallAdapterFactory(new ApiCallAdapterFactory())
                .addConverterFactory(FastJsonConverterFactory.create())
                .client(okHttpClient)
                .build();
    }

    public static class UIDInconsistencyException extends Exception{}

}
